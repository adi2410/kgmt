#SELFBOT PYHON3
------
- `apt update`
- `apt upgrade`
- `pkg install python`
- `apt install git`
- `apt install python3-pip`
- `pip3 install rsa`
- `pip3 install thrift==0.11.0`
- `pip3 install requests`
- `pip3 install bs4`
- `pip3 install gtts`
- `pip3 install pytz`
- `pip3 install humanfriendly`
- `pip3 install googletrans`
- `pip3 install pytz`
- `git clone https://github.com/gyevha2/Gie2`

- 'Cara Run Bot'
- Ketik -> `cd Gye2`
- Ketik -> `python3 gye.py`
- `Jangan Lupa Kalian isi Dulu Token nya`
- `Edit via nano Atau storage`

- 'untuk Run Via storage'
- `cd storage`
- `cd downloads`
- `cd Gye2`
- `python3 gye.py`

- thank id Line me ( aisyagye )
